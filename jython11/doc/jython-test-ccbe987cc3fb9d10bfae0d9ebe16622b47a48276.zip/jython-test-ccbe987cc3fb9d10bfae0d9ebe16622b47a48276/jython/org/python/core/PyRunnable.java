// Copyright � Corporation for National Research Initiatives
package org.python.core;

public interface PyRunnable {
    abstract public PyCode getMain();
}
