// Copyright � Corporation for National Research Initiatives
package org.python.core;

public class PyEllipsis extends PySingleton {
    public PyEllipsis() {
        super("Ellipsis");
    }
}
