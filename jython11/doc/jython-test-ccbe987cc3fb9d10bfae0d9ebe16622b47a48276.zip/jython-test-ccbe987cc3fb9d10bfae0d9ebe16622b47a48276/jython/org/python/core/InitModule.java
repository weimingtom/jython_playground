// Copyright � Corporation for National Research Initiatives

package org.python.core;

public interface InitModule {
    public abstract void initModule(PyObject dict);
}
