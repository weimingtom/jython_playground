package org.python.parser.ast;

import org.python.parser.SimpleNode;

public abstract class sliceType extends SimpleNode
{

}
