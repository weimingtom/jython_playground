package org.python.parser.ast;

import org.python.parser.SimpleNode;

public abstract class modType extends SimpleNode
{

}
