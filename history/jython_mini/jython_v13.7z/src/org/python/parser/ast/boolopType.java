package org.python.parser.ast;

public interface boolopType
{
	public static final int And = 1;
	public static final int Or = 2;

	public static final String[] boolopTypeNames = new String[] { "<undef>", "And", "Or", };
}
