package org.python.parser.ast;

public interface cmpopType
{
	public static final int Eq = 1;
	public static final int NotEq = 2;
	public static final int Lt = 3;
	public static final int LtE = 4;
	public static final int Gt = 5;
	public static final int GtE = 6;
	public static final int Is = 7;
	public static final int IsNot = 8;
	public static final int In = 9;
	public static final int NotIn = 10;

	public static final String[] cmpopTypeNames = new String[] { 
		"<undef>", 
		"Eq", 
		"NotEq", 
		"Lt", 
		"LtE", 
		"Gt", 
		"GtE", 
		"Is", 
		"IsNot", 
		"In", 
		"NotIn", 
	};
}
