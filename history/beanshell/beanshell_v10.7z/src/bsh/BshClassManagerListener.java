package bsh;

public interface BshClassManagerListener
{
	public void classLoaderChanged();
}
