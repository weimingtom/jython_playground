1. 代码风格调整，修改{}
2. 修改import
JThis
3. 检查多个类和类修饰符
移出内嵌类
Parser
Primitive
SimpleNode
XThis
4. 检查重载方法，重命名（小心覆盖机制）
5. 检查重载构造函数
BshMethod
CallStack
ExternalNameSpace
Interpreter
JavaCharStream
LHS
NameSpace
ParseException
Parser
Primitive
ReflectError
TargetError
TokenMgrError
UtilEvalError
UtilTargetError
Variable


