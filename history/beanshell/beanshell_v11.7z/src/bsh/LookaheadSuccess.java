package bsh;

public class LookaheadSuccess extends Error
{

}
