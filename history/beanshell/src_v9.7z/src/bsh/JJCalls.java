package bsh;

public class JJCalls
{
	public int gen;
	public Token first;
	public int arg;
	public JJCalls next;
}
