package bsh;

public interface NodeFilter
{
	public boolean isVisible(SimpleNode node);
}
