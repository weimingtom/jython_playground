package org.python.core;

// experimental PyMetaClass hook interface
public interface PyMetaClass {
}
