// Copyright (c) Corporation for National Research Initiatives

package org.python.compiler;

public abstract class Attribute
{
    public abstract void write(java.io.DataOutputStream s)
        throws java.io.IOException;
}
