package com.example.testmysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

public class TestMySQLActivity extends Activity {
	private final static boolean D = true;
	private final static String TAG = "TestMySQLActivity";
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        test();
    }
    
    /**
mysql> create table SampleTable(
    -> `str` varchar(255)
    -> );
Query OK, 0 rows affected (0.06 sec)

mysql> status;
...
TCP port:               3306
     */
    private void test() {
        Connection con = null;
        Statement stmt = null;
        ResultSet rset = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://192.168.1.100:3306/test","root", "");
            stmt = con.createStatement();
            String query = "insert into SampleTable (str) " + "values ('from Android!')";
            stmt.executeUpdate(query);
            rset = stmt.executeQuery("SELECT * FROM SampleTable");
            while (rset.next()) {
            	if (D) {
            		Log.d(TAG, rset.getString("str"));
            	}
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
            	if (rset != null) {
            		rset.close();
            	}
            	if (stmt != null) {
            		stmt.close();
            	}
            	if (con != null) {
            		con.close();
            	}
            } catch (SQLException e){
                e.printStackTrace();
            }
        }
    }
}