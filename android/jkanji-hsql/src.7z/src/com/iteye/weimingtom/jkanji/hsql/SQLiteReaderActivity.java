package com.iteye.weimingtom.jkanji.hsql;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

/**
 * D:/ugame/mydroid_data/database
 * @author Administrator
 *
 */
public class SQLiteReaderActivity extends Activity implements OnItemClickListener {
	private final static boolean D = true;
	private final static String TAG = "SQLiteReaderActivity";
	
	private static final boolean IS_FULL_TEXT = true; // no fulltext:37207; fulltext:
	private static final String PATH; 
	static {
		if (IS_FULL_TEXT) {
			PATH = "/sdcard/jkanji/db/dict_fulltext.sqlite";
		} else {
			PATH = "/sdcard/jkanji/db/dict.sqlite";
		}
	}
	
	private static final String TABLE_NAME = "words";
	
	private ListView viewListView;
	private EditText searchInput;
	private Button searchButton;
	private Typeface typeface;
	private List<WordRecord> records;
	private EfficientAdapter adapter;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		this.setContentView(R.layout.sqlite_reader);
		
		viewListView = (ListView) this.findViewById(R.id.viewListView);
		searchButton = (Button) this.findViewById(R.id.searchButton);
		searchInput = (EditText) this.findViewById(R.id.searchInput);
		
		records = new ArrayList<WordRecord>();
		typeface = Typefaces.get(this, "mplus-1m-regular.ttf");
		adapter = new EfficientAdapter(this, records, typeface);
		viewListView.setAdapter(adapter);
		viewListView.setFastScrollEnabled(true);
		viewListView.setSelection(0);
		viewListView.setOnItemClickListener(this);
		
		searchInput.setText("明日");
		searchButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (searchInput != null && searchInput.getText() != null) {
					String text = searchInput.getText().toString();
					long lastTime = System.currentTimeMillis();
					search(text);
					adapter.notifyDataSetChanged();
					System.out.println("time : " + (System.currentTimeMillis() - lastTime));
				}
			}
		});
	}
		
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
	}
	
	private final static class EfficientAdapter extends BaseAdapter {
        private LayoutInflater mInflater;
        private List<WordRecord> records;
        private Typeface typeface;
        
        public EfficientAdapter(Context context, List<WordRecord> records, Typeface typeface) {
            this.mInflater = LayoutInflater.from(context);
            this.records = records;
            this.typeface = typeface;
        }
        
        public int getCount() {
        	return records.size();
        }
        
        public Object getItem(int position) {
            return position;
        }

        public long getItemId(int position) {
            return position;
        }
        
        private WordRecord getWord(int index) {
    		return records.get(index);
        }
        
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder holder;
            if (convertView == null) {
                convertView = mInflater.inflate(R.layout.list_item, null);
                holder = new ViewHolder();
                holder.title = (TextView) convertView.findViewById(R.id.title);
                holder.title.setTypeface(typeface);
                holder.text = (TextView) convertView.findViewById(R.id.text);
                convertView.setTag(holder);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }
            
            String title = "";
            String text = "";
            WordRecord word = getWord(position);
			if (word != null) {
				title = word.word;
				text = word.meaning;
			}
            holder.title.setText(title);
            holder.text.setText(text);
            
            return convertView;
        }

        private class ViewHolder {
        	TextView title;
            TextView text;
        }
    }
	
	private class WordRecord {
		public int id;
		public String word;
		public String meaning;
		public int dict_id;
		
		public WordRecord(int id, String word, String meaning, int dict_id) {
			this.id = id;
			this.word = word;
			this.meaning = meaning;
			this.dict_id = dict_id;
		}
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
		
	}
	
	private static String tokenize(String str) {
		//return new StringBuffer(str).reverse().toString();
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);
			sb.append(c);
			if (c > 256) {
				sb.append(' ');
			}
		}
		return sb.toString();
	}
	
	/**
	 * @see com.iteye.weimingtom.jkanji.tools.DictDump
	 */
	private void search(String keyword) {
		SQLiteDatabase db = null;
		try {
			db = SQLiteDatabase.openDatabase(PATH, 
				null, 
				SQLiteDatabase.OPEN_READONLY | SQLiteDatabase.NO_LOCALIZED_COLLATORS);
			Cursor cursor = null;
			String selection = null;
			String[] selectionArgs = null;
			String[] columns = null;
			if (IS_FULL_TEXT) {
				selection = "word_tokenize MATCH ?";
				selectionArgs = new String[]{"\"" + tokenize(keyword) + "*\""};
				columns = new String[]{"rowid", "word", "meaning", "dict_id"};
			} else {
				selection = "word LIKE ?";
				selectionArgs = new String[]{"%" + keyword + "%"};
				columns = new String[]{"id", "word", "meaning", "dict_id"};
			}
			cursor = db.query(false, //destinct
					TABLE_NAME, //table
					columns, //columns
					selection, //"word LIKE ?", //selection
					selectionArgs, //new String[]{"%明日%"}, //selectionArgs
					null, //groupBy
					null, //having
					"word ASC", //orderBy
					null); //"0, 10"); //limit
			try {
				records.clear();
				while (cursor.moveToNext()) {
					int id = cursor.getInt(0);
					String word = cursor.getString(1);
					String meaning = cursor.getString(2);
					int dict_id = cursor.getInt(3);
					if (D) {
						Log.d(TAG,
							"id = " + id + "," +  
							"word = " + word + "," + 
							"meaning = " + meaning + "," + 
							"dict_id = " + dict_id);
					}
					records.add(new WordRecord(id, word, meaning, dict_id));
				}
			} catch (Throwable e) {
				e.printStackTrace();
			} finally {
				if (cursor != null) {
					cursor.close();
				}
			}
		} catch (Throwable e) {
			e.printStackTrace();
		} finally {
			if (db != null) {
				db.close();
			} 
		}
	}
}
