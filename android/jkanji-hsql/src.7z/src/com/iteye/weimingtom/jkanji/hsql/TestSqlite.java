package com.iteye.weimingtom.jkanji.hsql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import android.util.Log;

public class TestSqlite {

	/**
	 * @see http://stackoverflow.com/questions/1728476/does-android-support-jdbc
	 * @param args
	 */
	public static void main(String[] args) {
	    try {
	        String db = "jdbc:sqlite:" + getFilesDir() + "/test.db";
	        Class.forName("SQLite.JDBCDriver");
	        Connection conn = DriverManager.getConnection(db);
	        Statement stat = conn.createStatement();
	        stat.executeUpdate("create table primes (number int);");
	        stat.executeUpdate("insert into primes values (2);");
	        stat.executeUpdate("insert into primes values (3);");
	        stat.executeUpdate("insert into primes values (5);");
	        stat.executeUpdate("insert into primes values (7);");
	        ResultSet rs = stat.executeQuery("select * from primes");
	        boolean b = rs.first();
	        while (b) {
	            Log.d("JDBC", "Prime=" + rs.getInt(1));
	            b = rs.next();
	        }
	        conn.close();
	    } catch (Exception e) {
	        Log.e("JDBC", "Error", e);
	    }
	}
	
	private static String getFilesDir() {
		return null;
	}
}
