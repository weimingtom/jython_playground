package com.iteye.weimingtom.jkanji.hsql;

import java.io.IOException;
import java.sql.SQLException;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.os.Bundle;

/**
 * .timer ON
 * .header ON
 * .schema
 *  
 * @author Administrator
 *
 */
public class JkanjiHsqlActivity extends Activity {
	private static final String PATH = "/sdcard/jkanji/databases/sampledata.sqlite";
	
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		testSelect002();
	}
	
	public void testHsql() {
		TestHsql.main(null);
		/*
		DataBaseHelper myDbHelper = new DataBaseHelper(this);
		try {
			myDbHelper.createDataBase();
			myDbHelper.openDataBase();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
		*/
	}
	
	public void testSelect001() {
		SQLiteDatabase db = null;
		String tableName = "Product";
		try {
			db = SQLiteDatabase.openDatabase(PATH, 
				null, SQLiteDatabase.OPEN_READWRITE);
			Cursor cursor = null;
			cursor = db.query(tableName, null, null, null, null, null, null);
			try {
				while (cursor.moveToNext()) {
					int id = cursor.getInt(0);
					String name = cursor.getString(1);
					int price = cursor.getInt(2);
					System.out.println("ID = " + id + ", Name = " + name + ", Price = " + price);
				}
			} catch (Throwable e) {
				e.printStackTrace();
			} finally {
				if (cursor != null) {
					cursor.close();
				}
			}
		} catch (Throwable e) {
			e.printStackTrace();
		} finally {
			if (db != null) {
				db.close();
			} 
		}
	}
	
	public void testSelect002() {
		
		SQLiteDatabase db = null;
		String tableName = "Product";
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
        qb.setTables(tableName);
		try {
			db = SQLiteDatabase.openDatabase(PATH, 
				null, SQLiteDatabase.OPEN_READWRITE);
			Cursor cursor = null;
			cursor = qb.query(db, null, null, null, null, null, null);
			try {
				while (cursor.moveToNext()) {
					int id = cursor.getInt(0);
					String name = cursor.getString(1);
					int price = cursor.getInt(2);
					System.out.println("ID = " + id + ", Name = " + name + ", Price = " + price);
				}
			} catch (Throwable e) {
				e.printStackTrace();
			} finally {
				if (cursor != null) {
					cursor.close();
				}
			}
		} catch (Throwable e) {
			e.printStackTrace();
		} finally {
			if (db != null) {
				db.close();
			} 
		}
	}
}
